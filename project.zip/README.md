# school.project-l1-2022
The school project of the license 1 class 2022, university of yaounde 1
