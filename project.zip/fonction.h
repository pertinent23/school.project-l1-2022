#ifndef __FONCTION__H__
#define __FONCTION__H__

void Ajouter(void);
void Modifier(void);
void Supprimer(int);
void affiche(void);
void solvable(void);
void insolvable(void);
void statistiques(void);
void Suppression(void);
void recherche(int);
#endif